<?php

print ">".trim("   I'm here ")."<";

?>