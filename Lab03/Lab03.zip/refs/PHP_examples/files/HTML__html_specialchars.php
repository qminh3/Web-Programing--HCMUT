
<?php
   $input = "<<enough>>";
   echo htmlspecialchars($input);
?>